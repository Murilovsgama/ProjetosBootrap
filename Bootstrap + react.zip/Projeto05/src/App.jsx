
import './App.css'
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import Card from './Cads/Cards';


function App() {
  

  return (
    <>
     <Card/>
    </>
  )
}

export default App

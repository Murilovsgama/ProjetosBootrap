import Card from './CardUI';
import React, {Component} from 'react';
import img1 from '../assets/biscoito.jpg';
import img2 from '../assets/morango.jpg';
import img3 from '../assets/honey.jpeg';

class Cards extends Component {
  render() {
    return (
      <div className="container-fluid d-flex justify-content-center">
        <div className="row">
          <div className="col-md-4">
            <Card imgsrc={img1} title="Chocolate"/>
          </div>
          <div className="col-md-4">
            <Card imgsrc={img2} title="Morango"/>
          </div>
          <div className="col-md-4">
            <Card imgsrc={img3} title="Mel"/>
          </div>
        </div>
      </div>
    );
  }
}

export default Cards;